import "./FavoriteStocks.scss";

export default function FavoriteStocks() {
  return (
    <div className="FavoriteStocks">
      <h1>FavoriteStocks</h1>
    </div>
  );
}
