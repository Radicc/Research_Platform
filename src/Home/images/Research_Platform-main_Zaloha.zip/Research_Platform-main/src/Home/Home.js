import FirstSection from "./FirstSection";

export default function Home() {
  return (
    <div className="Home">
      <FirstSection />
    </div>
  );
}
