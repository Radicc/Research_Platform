import "./sass/_firstSection.scss";
import wallstreet_1 from "./images/wallstreet_1.jpg";

export default function FirstSection() {
  return (
    <div className="firstSection">
      <div className="titulContainer">
        <h1>SUCCESS IN ANY FIELD OF LIFE IS NOT DUE TO INBORN TRAITS</h1>
      </div>
    </div>
  );
}
