import "./Stocks.scss";

export default function Stocks() {
  return (
    <div className="Stocks">
      <h1>Stocks</h1>
    </div>
  );
}
