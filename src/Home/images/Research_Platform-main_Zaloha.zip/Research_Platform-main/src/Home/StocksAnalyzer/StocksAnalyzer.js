import "./StocksAnalyzer.scss";

export default function StocksAnalyzer() {
  return (
    <div className="StocksAnalyzer">
      <h1>StocksAnalyzer</h1>
    </div>
  );
}
